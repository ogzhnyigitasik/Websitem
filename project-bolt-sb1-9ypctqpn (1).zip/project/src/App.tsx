import FarazaApp from './faraza-app';

function App() {
  return <FarazaApp />;
}

export default App;
