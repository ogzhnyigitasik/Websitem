import { useState, useEffect } from "react";

const DARK = {
  bg: "#0A0E27",
  card: "#131829",
  card2: "#1A2340",
  border: "#1F2F4A",
  text: "#FFFFFF",
  sub: "#8B94A5",
  accent: "#00A8FF",
  accentSoft: "#00A8FF12",
  green: "#10B981",
  greenSoft: "#10B98115",
  amber: "#F59E0B",
  amberSoft: "#F59E0B15",
  blue: "#6366F1",
  blueSoft: "#6366F115",
};

const LIGHT = {
  bg: "#F8FAFC",
  card: "#FFFFFF",
  card2: "#F1F5F9",
  border: "#E2E8F0",
  text: "#0F172A",
  sub: "#64748B",
  accent: "#0EA5E9",
  accentSoft: "#0EA5E915",
  green: "#059669",
  greenSoft: "#05966915",
  amber: "#D97706",
  amberSoft: "#D9770615",
  blue: "#6366F1",
  blueSoft: "#6366F115",
};

const TABS = [
  { id: "home", icon: "🏠", label: "Əsas" },
  { id: "vehicle", icon: "🚗", label: "Araç" },
  { id: "service", icon: "🔧", label: "Xidmət" },
  { id: "emergency", icon: "🚨", label: "Fövqəladə" },
  { id: "shop", icon: "🛍", label: "Mağaza" },
  { id: "insurance", icon: "🛡", label: "Sığorta" },
];

const MECHANICS = [
  {
    id: 1,
    name: "Elnur Həsənov",
    shop: "Auto Pro Servis",
    brand: "BMW, Mercedes",
    dist: "1.2 km",
    rating: 4.9,
    reviews: 142,
    price: "₼45/saat",
    badge: "TOP",
    avail: true,
  },
  {
    id: 2,
    name: "Kamran Əliyev",
    shop: "KM Motors",
    brand: "Toyota, Honda",
    dist: "2.4 km",
    rating: 4.7,
    reviews: 87,
    price: "₼35/saat",
    badge: null,
    avail: true,
  },
  {
    id: 3,
    name: "Rauf Məmmədov",
    shop: "Speed Garage",
    brand: "Audi, VW",
    dist: "3.1 km",
    rating: 4.5,
    reviews: 203,
    price: "₼40/saat",
    badge: "SÜRƏTLI",
    avail: false,
  },
];

const PRODUCTS = [
  {
    id: 1,
    name: "Mobil 1 5W-40 4L",
    cat: "Motor Yağı",
    price: "₼68",
    oldPrice: "₼85",
    img: "🛢",
    rating: 4.8,
    sold: 320,
  },
  {
    id: 2,
    name: "Bridgestone 205/55R16",
    cat: "Təkər",
    price: "₼185",
    oldPrice: null,
    img: "⭕",
    rating: 4.7,
    sold: 89,
  },
  {
    id: 3,
    name: "Bosch Hava Filtresi",
    cat: "Filtr",
    price: "₼24",
    oldPrice: "₼30",
    img: "🔩",
    rating: 4.6,
    sold: 445,
  },
  {
    id: 4,
    name: "Pioneer MVH-S120UB",
    cat: "Multimedia",
    price: "₼210",
    oldPrice: null,
    img: "📻",
    rating: 4.5,
    sold: 56,
  },
];

const INSURANCES = [
  {
    id: 1,
    company: "AzSığorta",
    type: "KASKO",
    cover: "₼35,000",
    monthly: "₼89/ay",
    exp: "14 gün qalır",
    expColor: "#E8373D",
    star: 4.8,
    badge: "Ən Populyar",
  },
  {
    id: 2,
    company: "Pasha Sığorta",
    type: "ICBM",
    cover: "₼25,000",
    monthly: "₼45/ay",
    exp: "112 gün qalır",
    expColor: "#22D07A",
    star: 4.6,
    badge: null,
  },
  {
    id: 3,
    company: "ATƏŞGAH",
    type: "KASKO+ICBM",
    cover: "₼50,000",
    monthly: "₼124/ay",
    exp: "112 gün qalır",
    expColor: "#22D07A",
    star: 4.9,
    badge: "Premium",
  },
];

const NOTIFS = [
  {
    icon: "⚠",
    text: "Yağ dəyişimi vaxtıdır — 500 km qalıb",
    color: "#F59E0B",
    time: "İndi",
  },
  {
    icon: "📋",
    text: "KASKO sigorta 14 günə bitir",
    color: "#EF4444",
    time: "2s əvvəl",
  },
  {
    icon: "✓",
    text: "Randevu təsdiqləndi — Elnur Həsənov, sabah 10:00",
    color: "#10B981",
    time: "1g əvvəl",
  },
];

export default function FarazaApp() {
  const [dark, setDark] = useState(true);
  const [tab, setTab] = useState("home");
  const [cart, setCart] = useState([]);
  const [booked, setBooked] = useState(null);
  const [toast, setToast] = useState(null);
  const [activeChart, setActiveChart] = useState(2);

  const t = dark ? DARK : LIGHT;

  const showToast = (msg, color = "#10B981") => {
    setToast({ msg, color });
    setTimeout(() => setToast(null), 2400);
  };

  const fuelData = [38, 44, 41, 52, 47, 55, 49];
  const fuelDays = ["B.E", "Ç.A", "Çər", "C.A", "Cüm", "Şnb", "Baz"];

  const css = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap');
    * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
    body { background: ${t.bg}; }
    ::-webkit-scrollbar { display: none; }
    .screen { animation: fadeUp 0.4s cubic-bezier(0.23, 1, 0.320, 1); }
    @keyframes fadeUp { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
    @keyframes slideIn { from { opacity:0; transform:translateX(-20px); } to { opacity:1; transform:translateX(0); } }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }
    @keyframes shimmer { 0% { transform: translateX(-100%); } 100% { transform: translateX(100%); } }
    .tap { transition: all 0.2s cubic-bezier(0.23, 1, 0.320, 1); cursor: pointer; }
    .tap:active { transform: scale(0.96); }
    .tab-btn { transition: all 0.3s cubic-bezier(0.23, 1, 0.320, 1); cursor: pointer; }
    .scroll-x { overflow-x: auto; scrollbar-width: none; }
    input { outline: none; }
  `;

  const Phone = ({ children }) => (
    <div
      style={{
        fontFamily: "'Inter', sans-serif",
        background: t.bg,
        minHeight: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "flex-start",
        padding: "0",
      }}
    >
      <style>{css}</style>
      <div
        style={{
          width: "100%",
          maxWidth: 420,
          minHeight: "100vh",
          background: t.bg,
          position: "relative",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* Status bar */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            padding: "12px 20px 6px",
            fontSize: 12,
            fontWeight: 600,
            color: t.sub,
          }}
        >
          <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>9:41</span>
          <div
            style={{
              width: 120,
              height: 14,
              background: t.card2,
              borderRadius: 10,
            }}
          />
          <span>📶 🔋</span>
        </div>
        {children}
      </div>
    </div>
  );

  const Card = ({ children, style = {}, onTap }) => (
    <div
      className={onTap ? "tap" : ""}
      onClick={onTap}
      style={{
        background: t.card,
        borderRadius: 16,
        border: `1px solid ${t.border}`,
        backdropFilter: "blur(20px)",
        ...style,
      }}
    >
      {children}
    </div>
  );

  const Chip = ({ label, color, bg }) => (
    <span
      style={{
        background: bg,
        color,
        borderRadius: 8,
        padding: "4px 11px",
        fontSize: 11,
        fontWeight: 600,
        letterSpacing: 0.3,
      }}
    >
      {label}
    </span>
  );

  const Stars = ({ n }) => (
    <span style={{ color: t.amber, fontSize: 11 }}>
      {"★".repeat(Math.floor(n))}
      {"☆".repeat(5 - Math.floor(n))}
    </span>
  );

  const HomeScreen = () => (
    <div className="screen" style={{ flex: 1, overflow: "auto", paddingBottom: 90 }}>
      {/* Header */}
      <div
        style={{
          padding: "16px 20px 8px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div>
          <div
            style={{
              fontSize: 28,
              fontWeight: 800,
              color: t.text,
              letterSpacing: -0.8,
            }}
          >
            Faraza
          </div>
          <div style={{ fontSize: 12, color: t.sub, marginTop: 2 }}>
            Bakı, Azərbaycan
          </div>
        </div>
        <div
          className="tap"
          onClick={() => setDark(!dark)}
          style={{
            background: t.card,
            border: `1px solid ${t.border}`,
            borderRadius: 12,
            padding: "10px 12px",
            fontSize: 16,
            cursor: "pointer",
          }}
        >
          {dark ? "☀️" : "🌙"}
        </div>
      </div>

      {/* Premium Vehicle Card */}
      <div style={{ margin: "16px 20px 0" }}>
        <Card
          style={{
            padding: "20px",
            background: `linear-gradient(135deg, ${t.accent}20, ${t.blue}15)`,
            border: `1px solid ${t.border}`,
            position: "relative",
            overflow: "hidden",
          }}
          onTap={() => setTab("vehicle")}
        >
          <div
            style={{
              position: "absolute",
              right: -40,
              top: -40,
              width: 200,
              height: 200,
              borderRadius: "50%",
              background: `${t.accent}08`,
              filter: "blur(40px)",
            }}
          />
          <div style={{ position: "relative", zIndex: 1 }}>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
              }}
            >
              <div>
                <div
                  style={{
                    fontSize: 11,
                    color: t.sub,
                    fontWeight: 600,
                    letterSpacing: 1.2,
                    textTransform: "uppercase",
                  }}
                >
                  Mənim Aracım
                </div>
                <div
                  style={{
                    fontSize: 26,
                    fontWeight: 800,
                    color: t.text,
                    marginTop: 6,
                    letterSpacing: -0.5,
                  }}
                >
                  BMW 520d
                </div>
                <div
                  style={{
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: 13,
                    color: t.accent,
                    marginTop: 4,
                    fontWeight: 600,
                  }}
                >
                  10-AB-567
                </div>
              </div>
              <div style={{ fontSize: 56, opacity: 0.9 }}>🚗</div>
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr 1fr",
                gap: 12,
                marginTop: 18,
              }}
            >
              {[
                {
                  label: "Kilometr",
                  value: "87,430",
                  unit: "km",
                  color: t.accent,
                },
                {
                  label: "Yanacaq",
                  value: "68",
                  unit: "%",
                  color: t.green,
                },
                {
                  label: "Baxım",
                  value: "500",
                  unit: "km",
                  color: t.amber,
                },
              ].map((item) => (
                <div
                  key={item.label}
                  style={{
                    background: `${t.card2}80`,
                    borderRadius: 12,
                    padding: "10px 12px",
                    backdropFilter: "blur(10px)",
                    border: `1px solid ${t.border}`,
                  }}
                >
                  <div
                    style={{
                      fontSize: 9,
                      color: t.sub,
                      fontWeight: 600,
                      textTransform: "uppercase",
                      letterSpacing: 0.5,
                    }}
                  >
                    {item.label}
                  </div>
                  <div
                    style={{
                      fontSize: 17,
                      fontWeight: 800,
                      color: item.color,
                      marginTop: 4,
                    }}
                  >
                    {item.value}
                    <span
                      style={{
                        fontSize: 9,
                        fontWeight: 500,
                        color: t.sub,
                        marginLeft: 3,
                      }}
                    >
                      {item.unit}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* Quick Actions */}
      <div style={{ padding: "22px 20px 0" }}>
        <div
          style={{
            fontSize: 14,
            fontWeight: 700,
            color: t.text,
            marginBottom: 14,
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}
        >
          Sürətli Giriş
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12 }}>
          {[
            {
              icon: "🚛",
              label: "Evakuator",
              desc: "Fövqəladə",
              color: t.accent,
              bg: t.accentSoft,
              tab: "emergency",
            },
            {
              icon: "🔧",
              label: "Usta",
              desc: "Xidmət",
              color: t.blue,
              bg: t.blueSoft,
              tab: "service",
            },
            {
              icon: "🛍",
              label: "Mağaza",
              desc: "Ehtiyat",
              color: t.green,
              bg: t.greenSoft,
              tab: "shop",
            },
            {
              icon: "🛡",
              label: "Sığorta",
              desc: "Polislər",
              color: t.amber,
              bg: t.amberSoft,
              tab: "insurance",
            },
          ].map((a) => (
            <div
              key={a.label}
              className="tap"
              onClick={() => setTab(a.tab)}
              style={{
                background: a.bg,
                border: `1px solid ${t.border}`,
                borderRadius: 14,
                padding: "16px 14px",
                textAlign: "center",
                cursor: "pointer",
              }}
            >
              <div style={{ fontSize: 32, marginBottom: 8 }}>{a.icon}</div>
              <div
                style={{
                  fontSize: 13,
                  fontWeight: 700,
                  color: t.text,
                  marginBottom: 2,
                }}
              >
                {a.label}
              </div>
              <div style={{ fontSize: 11, color: a.color, fontWeight: 500 }}>
                {a.desc}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Notifications */}
      <div style={{ padding: "22px 20px 0" }}>
        <div
          style={{
            fontSize: 14,
            fontWeight: 700,
            color: t.text,
            marginBottom: 12,
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}
        >
          Bildirişlər
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {NOTIFS.map((n, i) => (
            <Card
              key={i}
              style={{
                padding: "14px 16px",
                display: "flex",
                alignItems: "center",
                gap: 12,
              }}
            >
              <div
                style={{
                  width: 38,
                  height: 38,
                  borderRadius: 10,
                  background: n.color + "20",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 17,
                  flexShrink: 0,
                }}
              >
                {n.icon}
              </div>
              <div style={{ flex: 1 }}>
                <div
                  style={{
                    fontSize: 13,
                    fontWeight: 500,
                    color: t.text,
                    lineHeight: 1.4,
                  }}
                >
                  {n.text}
                </div>
                <div style={{ fontSize: 11, color: t.sub, marginTop: 3 }}>
                  {n.time}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );

  const VehicleScreen = () => (
    <div className="screen" style={{ flex: 1, overflow: "auto", paddingBottom: 90 }}>
      <div
        style={{
          padding: "16px 20px 0",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div style={{ fontSize: 24, fontWeight: 800, color: t.text }}>
          Araç Paneli
        </div>
        <Chip label="2023" color={t.blue} bg={t.blueSoft} />
      </div>

      {/* Stats Grid */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 12,
          margin: "16px 20px 0",
        }}
      >
        {[
          {
            label: "Kilometr",
            value: "87,430 km",
            icon: "🛣",
            color: t.accent,
          },
          {
            label: "Yanacaq",
            value: "68% — 42L",
            icon: "⛽",
            color: t.green,
          },
          {
            label: "Motor",
            value: "Əla",
            icon: "💚",
            color: t.green,
          },
          {
            label: "Baxım",
            value: "500 km",
            icon: "⚠️",
            color: t.amber,
          },
        ].map((s) => (
          <Card key={s.label} style={{ padding: "16px" }}>
            <div style={{ fontSize: 24, marginBottom: 8 }}>{s.icon}</div>
            <div
              style={{
                fontSize: 10,
                color: t.sub,
                fontWeight: 600,
                textTransform: "uppercase",
                letterSpacing: 0.5,
                marginBottom: 4,
              }}
            >
              {s.label}
            </div>
            <div style={{ fontSize: 15, fontWeight: 700, color: s.color }}>
              {s.value}
            </div>
          </Card>
        ))}
      </div>

      {/* Fuel Chart */}
      <div style={{ margin: "16px 20px 0" }}>
        <Card style={{ padding: "18px 20px" }}>
          <div
            style={{
              fontSize: 14,
              fontWeight: 700,
              color: t.text,
              marginBottom: 16,
            }}
          >
            Yanacaq İstehlakı
          </div>
          <div
            style={{
              display: "flex",
              gap: 6,
              alignItems: "flex-end",
              height: 80,
            }}
          >
            {fuelData.map((v, i) => (
              <div
                key={i}
                style={{
                  flex: 1,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 4,
                  cursor: "pointer",
                }}
                onClick={() => setActiveChart(i)}
              >
                <div
                  style={{
                    fontSize: 8,
                    color:
                      activeChart === i ? t.accent : t.sub,
                    fontWeight: 700,
                  }}
                >
                  {v}
                </div>
                <div
                  style={{
                    width: "100%",
                    borderRadius: "6px 6px 0 0",
                    height: `${(v / 60) * 70}px`,
                    background:
                      activeChart === i ? t.accent : t.card2,
                    transition: "all 0.3s",
                  }}
                />
                <div style={{ fontSize: 9, color: t.sub }}>
                  {fuelDays[i]}
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Maintenance History */}
      <div style={{ margin: "16px 20px 0" }}>
        <div
          style={{
            fontSize: 14,
            fontWeight: 700,
            color: t.text,
            marginBottom: 12,
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}
        >
          Baxım Tarixi
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {[
            {
              type: "Yağ Dəyişimi",
              date: "12 Yan 2025",
              km: "85,000",
              cost: "₼85",
              done: true,
            },
            {
              type: "Əyləc Baxımı",
              date: "03 Mar 2025",
              km: "87,000",
              cost: "₼120",
              done: true,
            },
            {
              type: "Filtr Dəyişimi",
              date: "Planlaşdırılmış",
              km: "88,000",
              cost: "—",
              done: false,
            },
          ].map((m, i) => (
            <Card
              key={i}
              style={{
                padding: "14px 16px",
                display: "flex",
                alignItems: "center",
                gap: 12,
              }}
            >
              <div
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 10,
                  background: m.done ? t.greenSoft : t.amberSoft,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 16,
                  flexShrink: 0,
                }}
              >
                {m.done ? "✓" : "⏳"}
              </div>
              <div style={{ flex: 1 }}>
                <div
                  style={{
                    fontSize: 14,
                    fontWeight: 600,
                    color: t.text,
                  }}
                >
                  {m.type}
                </div>
                <div style={{ fontSize: 11, color: t.sub, marginTop: 2 }}>
                  {m.date} · {m.km} km
                </div>
              </div>
              <div
                style={{
                  fontSize: 14,
                  fontWeight: 700,
                  color: m.done ? t.green : t.amber,
                }}
              >
                {m.cost}
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Alert */}
      <div style={{ margin: "16px 20px 0" }}>
        <Card
          style={{
            padding: "16px",
            background: t.accentSoft,
            border: `1px solid ${t.accent}40`,
          }}
        >
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <span style={{ fontSize: 24 }}>⚠️</span>
            <div>
              <div
                style={{
                  fontSize: 14,
                  fontWeight: 700,
                  color: t.accent,
                }}
              >
                Diqqət tələb olunur
              </div>
              <div style={{ fontSize: 12, color: t.sub, marginTop: 2 }}>
                Yağ dəyişimi: 500 km qalıb
              </div>
            </div>
          </div>
          <div
            className="tap"
            onClick={() => setTab("service")}
            style={{
              marginTop: 12,
              background: t.accent,
              borderRadius: 10,
              padding: "10px",
              textAlign: "center",
              color: "#fff",
              fontSize: 13,
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            Usta Tap →
          </div>
        </Card>
      </div>
    </div>
  );

  const ServiceScreen = () => (
    <div className="screen" style={{ flex: 1, overflow: "auto", paddingBottom: 90 }}>
      <div
        style={{
          padding: "16px 20px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div style={{ fontSize: 24, fontWeight: 800, color: t.text }}>
          Usta & Servis
        </div>
        <Chip label="BMW" color={t.accent} bg={t.accentSoft} />
      </div>

      {/* Search */}
      <div style={{ margin: "0 20px 16px", position: "relative" }}>
        <div
          style={{
            position: "absolute",
            left: 14,
            top: "50%",
            transform: "translateY(-50%)",
            fontSize: 16,
            color: t.sub,
          }}
        >
          🔍
        </div>
        <input
          style={{
            width: "100%",
            background: t.card,
            border: `1px solid ${t.border}`,
            borderRadius: 12,
            padding: "12px 14px 12px 42px",
            fontSize: 14,
            color: t.text,
            fontFamily: "'Inter', sans-serif",
          }}
          placeholder="Usta axtar..."
        />
      </div>

      {/* Mechanics */}
      <div style={{ padding: "0 20px", display: "flex", flexDirection: "column", gap: 12 }}>
        {MECHANICS.map((m) => (
          <Card key={m.id} style={{ padding: "16px" }}>
            <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
              <div
                style={{
                  width: 48,
                  height: 48,
                  borderRadius: 12,
                  background: `linear-gradient(135deg, ${t.accent}30, ${t.blue}20)`,
                  border: `1px solid ${t.border}`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 24,
                  flexShrink: 0,
                }}
              >
                🔧
              </div>
              <div style={{ flex: 1 }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "flex-start",
                  }}
                >
                  <div>
                    <div
                      style={{
                        fontSize: 15,
                        fontWeight: 700,
                        color: t.text,
                      }}
                    >
                      {m.name}
                    </div>
                    <div style={{ fontSize: 12, color: t.sub, marginTop: 2 }}>
                      {m.shop}
                    </div>
                  </div>
                  {m.badge && (
                    <Chip
                      label={m.badge}
                      color={t.accent}
                      bg={t.accentSoft}
                    />
                  )}
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: 6,
                    alignItems: "center",
                    marginTop: 8,
                  }}
                >
                  <Stars n={m.rating} />
                  <span style={{ fontSize: 12, fontWeight: 700, color: t.text }}>
                    {m.rating}
                  </span>
                  <span style={{ fontSize: 11, color: t.sub }}>
                    ({m.reviews})
                  </span>
                </div>
                <div
                  style={{
                    display: "flex",
                    gap: 12,
                    marginTop: 8,
                    fontSize: 12,
                  }}
                >
                  <span style={{ color: t.sub }}>📍 {m.dist}</span>
                  <span style={{ color: t.accent, fontWeight: 600 }}>
                    🔧 {m.brand}
                  </span>
                </div>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    marginTop: 12,
                  }}
                >
                  <div
                    style={{
                      fontSize: 16,
                      fontWeight: 800,
                      color: t.green,
                    }}
                  >
                    {m.price}
                  </div>
                  <div
                    className="tap"
                    onClick={() => {
                      setBooked(m.id);
                      showToast(`Randevu göndərildi — ${m.name}`);
                    }}
                    style={{
                      background:
                        m.avail ? t.accent : t.card2,
                      color: m.avail ? "#fff" : t.sub,
                      borderRadius: 10,
                      padding: "9px 16px",
                      fontSize: 13,
                      fontWeight: 700,
                      cursor: m.avail ? "pointer" : "default",
                      border: `1px solid ${m.avail ? t.accent : t.border}`,
                    }}
                  >
                    {booked === m.id ? "✓ Göndərildi" : m.avail ? "Randevu Al" : "Məşğul"}
                  </div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );

  const EmergencyScreen = () => {
    const [requested, setRequested] = useState(false);
    const [eta, setEta] = useState(12);
    useEffect(() => {
      if (requested) {
        const t = setInterval(() => setEta((e) => (e > 1 ? e - 1 : 1)), 3000);
        return () => clearInterval(t);
      }
    }, [requested]);
    return (
      <div className="screen" style={{ flex: 1, overflow: "auto", paddingBottom: 90 }}>
        <div style={{ padding: "16px 20px" }}>
          <div style={{ fontSize: 24, fontWeight: 800, color: t.text }}>
            Fövqəladə Kömək
          </div>
          <div style={{ fontSize: 12, color: t.sub, marginTop: 3 }}>
            Evakuator xidməti
          </div>
        </div>

        {/* Map Mockup */}
        <div
          style={{
            margin: "12px 20px",
            borderRadius: 14,
            overflow: "hidden",
            position: "relative",
            height: 200,
            background: dark ? "#1A2A40" : "#D4E5F7",
            border: `1px solid ${t.border}`,
          }}
        >
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              style={{
                position: "absolute",
                left: 0,
                right: 0,
                top: `${i * 16.6}%`,
                height: 1,
                background: `${t.text}05`,
              }}
            />
          ))}
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              style={{
                position: "absolute",
                top: 0,
                bottom: 0,
                left: `${i * 16.6}%`,
                width: 1,
                background: `${t.text}05`,
              }}
            />
          ))}

          <div
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              transform: "translate(-50%,-50%)",
              textAlign: "center",
            }}
          >
            <div
              style={{
                background: t.accent,
                width: 36,
                height: 36,
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 18,
                margin: "0 auto",
                boxShadow: `0 0 20px ${t.accent}40`,
              }}
            >
              🚗
            </div>
          </div>

          {[
            { x: "20%", y: "25%", d: "1.2 km" },
            { x: "75%", y: "35%", d: "2.1 km" },
          ].map((pos, i) => (
            <div
              key={i}
              style={{
                position: "absolute",
                left: pos.x,
                top: pos.y,
                transform: "translate(-50%,-50%)",
              }}
            >
              <div
                style={{
                  background: t.amber,
                  borderRadius: 8,
                  padding: "4px 8px",
                  fontSize: 10,
                  fontWeight: 700,
                  color: "#000",
                  whiteSpace: "nowrap",
                }}
              >
                🚛 {pos.d}
              </div>
            </div>
          ))}
        </div>

        {requested && (
          <div style={{ margin: "14px 20px 0" }}>
            <Card
              style={{
                padding: "16px 18px",
                background: t.greenSoft,
                border: `1px solid ${t.green}40`,
                display: "flex",
                alignItems: "center",
                gap: 14,
              }}
            >
              <div style={{ fontSize: 32 }}>🚛</div>
              <div style={{ flex: 1 }}>
                <div
                  style={{
                    fontSize: 14,
                    fontWeight: 700,
                    color: t.green,
                  }}
                >
                  Evakuator Yoldadır!
                </div>
                <div style={{ fontSize: 11, color: t.sub, marginTop: 2 }}>
                  Nazim Şofer · 055-XXX-XXXX
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div
                  style={{
                    fontSize: 22,
                    fontWeight: 800,
                    color: t.green,
                  }}
                >
                  {eta}
                </div>
                <div style={{ fontSize: 10, color: t.sub }}>dəq</div>
              </div>
            </Card>
          </div>
        )}

        {/* Services */}
        <div style={{ margin: "14px 20px 0" }}>
          <div
            style={{
              fontSize: 14,
              fontWeight: 700,
              color: t.text,
              marginBottom: 12,
              textTransform: "uppercase",
              letterSpacing: 0.5,
            }}
          >
            Yaxın Xidmətlər
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {[
              {
                name: "Bakı Evakuator 24/7",
                dist: "1.2 km",
                eta: "~8 dəq",
                price: "₼30",
              },
              {
                name: "SOS Avtokömək",
                dist: "2.1 km",
                eta: "~12 dəq",
                price: "₼25",
              },
            ].map((s, i) => (
              <Card
                key={i}
                style={{
                  padding: "14px",
                  display: "flex",
                  gap: 12,
                  alignItems: "center",
                }}
              >
                <div
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 10,
                    background: t.amberSoft,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 20,
                    flexShrink: 0,
                  }}
                >
                  🚛
                </div>
                <div style={{ flex: 1 }}>
                  <div
                    style={{
                      fontSize: 13,
                      fontWeight: 700,
                      color: t.text,
                    }}
                  >
                    {s.name}
                  </div>
                  <div style={{ fontSize: 11, color: t.sub, marginTop: 2 }}>
                    {s.dist} · ETA: {s.eta} · {s.price}
                  </div>
                </div>
                <div
                  className="tap"
                  onClick={() => {
                    setRequested(true);
                    showToast("Evakuator çağırıldı!");
                  }}
                  style={{
                    background:
                      i === 0 ? t.accent : "transparent",
                    border:
                      i === 0
                        ? "none"
                        : `1px solid ${t.border}`,
                    color: i === 0 ? "#fff" : t.accent,
                    borderRadius: 10,
                    padding: "8px 12px",
                    fontSize: 12,
                    fontWeight: 700,
                    cursor: "pointer",
                  }}
                >
                  {i === 0 ? "Çağır" : "📞"}
                </div>
              </Card>
            ))}
          </div>
        </div>

        <div style={{ margin: "16px 20px 0" }}>
          <div
            className="tap"
            onClick={() => {
              setRequested(true);
              showToast("Evakuator çağırıldı!");
            }}
            style={{
              background: t.accent,
              borderRadius: 12,
              padding: "16px",
              textAlign: "center",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 10,
            }}
          >
            <span style={{ fontSize: 20 }}>🚨</span>
            <span style={{ fontSize: 15, fontWeight: 800, color: "#fff" }}>
              Evakuator Çağır
            </span>
          </div>
        </div>
      </div>
    );
  };

  const ShopScreen = () => (
    <div className="screen" style={{ flex: 1, overflow: "auto", paddingBottom: 90 }}>
      <div
        style={{
          padding: "16px 20px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div style={{ fontSize: 24, fontWeight: 800, color: t.text }}>
          Mağaza
        </div>
        <div style={{ position: "relative" }}>
          <div style={{ fontSize: 20 }}>🛍</div>
          {cart.length > 0 && (
            <div
              style={{
                position: "absolute",
                top: -4,
                right: -4,
                background: t.accent,
                borderRadius: "50%",
                width: 18,
                height: 18,
                fontSize: 10,
                fontWeight: 800,
                color: "#fff",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {cart.length}
            </div>
          )}
        </div>
      </div>

      {/* Search */}
      <div style={{ margin: "12px 20px 14px", position: "relative" }}>
        <div
          style={{
            position: "absolute",
            left: 14,
            top: "50%",
            transform: "translateY(-50%)",
            fontSize: 16,
            color: t.sub,
          }}
        >
          🔍
        </div>
        <input
          style={{
            width: "100%",
            background: t.card,
            border: `1px solid ${t.border}`,
            borderRadius: 12,
            padding: "12px 14px 12px 42px",
            fontSize: 14,
            color: t.text,
            fontFamily: "'Inter', sans-serif",
          }}
          placeholder="Ehtiyat axtar..."
        />
      </div>

      {/* Products */}
      <div style={{ padding: "0 20px" }}>
        <div
          style={{
            fontSize: 14,
            fontWeight: 700,
            color: t.text,
            marginBottom: 12,
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}
        >
          Populyar Məhsullar
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 12,
          }}
        >
          {PRODUCTS.map((p) => (
            <Card
              key={p.id}
              style={{
                padding: "14px",
                display: "flex",
                flexDirection: "column",
              }}
            >
              <div
                style={{
                  background: t.card2,
                  borderRadius: 10,
                  height: 90,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 40,
                  marginBottom: 10,
                }}
              >
                {p.img}
              </div>
              <div
                style={{
                  fontSize: 10,
                  color: t.sub,
                  fontWeight: 600,
                  marginBottom: 4,
                  textTransform: "uppercase",
                }}
              >
                {p.cat}
              </div>
              <div
                style={{
                  fontSize: 13,
                  fontWeight: 700,
                  color: t.text,
                  lineHeight: 1.3,
                  marginBottom: 6,
                  flex: 1,
                }}
              >
                {p.name}
              </div>
              <div
                style={{
                  display: "flex",
                  gap: 4,
                  alignItems: "center",
                  marginBottom: 10,
                }}
              >
                <Stars n={p.rating} />
                <span style={{ fontSize: 10, color: t.sub }}>
                  ({p.sold})
                </span>
              </div>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <div>
                  <div
                    style={{
                      fontSize: 16,
                      fontWeight: 800,
                      color: t.accent,
                    }}
                  >
                    {p.price}
                  </div>
                  {p.oldPrice && (
                    <div
                      style={{
                        fontSize: 10,
                        color: t.sub,
                        textDecoration: "line-through",
                      }}
                    >
                      {p.oldPrice}
                    </div>
                  )}
                </div>
                <div
                  className="tap"
                  onClick={() => {
                    setCart((c) => [...c, p]);
                    showToast(`${p.name.slice(0, 12)}... əlavə edildi`);
                  }}
                  style={{
                    background: t.accent,
                    borderRadius: 10,
                    width: 34,
                    height: 34,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 18,
                    cursor: "pointer",
                    color: "#fff",
                    fontWeight: 700,
                  }}
                >
                  +
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );

  const InsuranceScreen = () => (
    <div className="screen" style={{ flex: 1, overflow: "auto", paddingBottom: 90 }}>
      <div style={{ padding: "16px 20px" }}>
        <div style={{ fontSize: 24, fontWeight: 800, color: t.text }}>
          Sığorta & Kasko
        </div>
        <div style={{ fontSize: 12, color: t.sub, marginTop: 3 }}>
          BMW 520d · 10-AB-567
        </div>
      </div>

      {/* Active Policy Alert */}
      <div style={{ margin: "12px 20px 0" }}>
        <Card
          style={{
            padding: "16px 18px",
            background: t.accentSoft,
            border: `1px solid ${t.accent}40`,
          }}
        >
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <div style={{ fontSize: 28 }}>🛡️</div>
            <div style={{ flex: 1 }}>
              <div
                style={{
                  fontSize: 14,
                  fontWeight: 700,
                  color: t.accent,
                }}
              >
                KASKO — 14 gün qalır!
              </div>
              <div style={{ fontSize: 11, color: t.sub, marginTop: 2 }}>
                AzSığorta · Bitmə: 10 Apr 2025
              </div>
            </div>
            <div
              className="tap"
              onClick={() => showToast("Yeniləmə səhifəsinə keçildi")}
              style={{
                background: t.accent,
                borderRadius: 8,
                padding: "8px 12px",
                fontSize: 11,
                fontWeight: 700,
                color: "#fff",
                cursor: "pointer",
              }}
            >
              Yenilə
            </div>
          </div>
          <div
            style={{
              marginTop: 12,
              background: dark ? "#1A2A40" : "#FFE8E8",
              borderRadius: 6,
              height: 6,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                width: "5%",
                height: "100%",
                background: t.accent,
                borderRadius: 6,
              }}
            />
          </div>
        </Card>
      </div>

      {/* Stats */}
      <div style={{ display: "flex", gap: 10, margin: "16px 20px" }}>
        {[
          { label: "Polislər", value: "2", icon: "📋", color: t.blue },
          {
            label: "Ödənilmiş",
            value: "₼267",
            icon: "💳",
            color: t.green,
          },
          { label: "Hadisə", value: "0", icon: "🔰", color: t.sub },
        ].map((s) => (
          <Card
            key={s.label}
            style={{
              flex: 1,
              padding: "14px 12px",
              textAlign: "center",
            }}
          >
            <div style={{ fontSize: 18, marginBottom: 6 }}>{s.icon}</div>
            <div
              style={{
                fontSize: 17,
                fontWeight: 800,
                color: s.color,
              }}
            >
              {s.value}
            </div>
            <div style={{ fontSize: 9, color: t.sub, marginTop: 3 }}>
              {s.label}
            </div>
          </Card>
        ))}
      </div>

      {/* Offers */}
      <div style={{ padding: "0 20px 0" }}>
        <div
          style={{
            fontSize: 14,
            fontWeight: 700,
            color: t.text,
            marginBottom: 12,
            textTransform: "uppercase",
            letterSpacing: 0.5,
          }}
        >
          Sığorta Təklifləri
        </div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: 12,
          }}
        >
          {INSURANCES.map((ins) => (
            <Card key={ins.id} style={{ padding: "18px" }}>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "flex-start",
                  marginBottom: 12,
                }}
              >
                <div>
                  <div
                    style={{
                      display: "flex",
                      gap: 8,
                      alignItems: "center",
                    }}
                  >
                    <div
                      style={{
                        fontSize: 16,
                        fontWeight: 800,
                        color: t.text,
                      }}
                    >
                      {ins.company}
                    </div>
                    {ins.badge && (
                      <Chip
                        label={ins.badge}
                        color={t.accent}
                        bg={t.accentSoft}
                      />
                    )}
                  </div>
                  <div style={{ fontSize: 11, color: t.sub, marginTop: 3 }}>
                    {ins.type}
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div
                    style={{
                      fontSize: 16,
                      fontWeight: 800,
                      color: t.green,
                    }}
                  >
                    {ins.monthly}
                  </div>
                  <Stars n={ins.star} />
                </div>
              </div>
              <div
                style={{
                  display: "flex",
                  gap: 8,
                  marginBottom: 12,
                }}
              >
                <div
                  style={{
                    flex: 1,
                    background: t.card2,
                    borderRadius: 10,
                    padding: "10px",
                    border: `1px solid ${t.border}`,
                  }}
                >
                  <div
                    style={{
                      fontSize: 9,
                      color: t.sub,
                      fontWeight: 600,
                      textTransform: "uppercase",
                    }}
                  >
                    Əhatə
                  </div>
                  <div
                    style={{
                      fontSize: 14,
                      fontWeight: 700,
                      color: t.text,
                      marginTop: 3,
                    }}
                  >
                    {ins.cover}
                  </div>
                </div>
                <div
                  style={{
                    flex: 1,
                    background: t.card2,
                    borderRadius: 10,
                    padding: "10px",
                    border: `1px solid ${t.border}`,
                  }}
                >
                  <div
                    style={{
                      fontSize: 9,
                      color: t.sub,
                      fontWeight: 600,
                      textTransform: "uppercase",
                    }}
                  >
                    Status
                  </div>
                  <div
                    style={{
                      fontSize: 12,
                      fontWeight: 700,
                      color: ins.expColor,
                      marginTop: 3,
                    }}
                  >
                    {ins.exp}
                  </div>
                </div>
              </div>
              <div style={{ display: "flex", gap: 10 }}>
                <div
                  className="tap"
                  onClick={() =>
                    showToast(`${ins.company} — alış başladıldı`)
                  }
                  style={{
                    flex: 1,
                    background: t.accent,
                    borderRadius: 10,
                    padding: "12px",
                    textAlign: "center",
                    color: "#fff",
                    fontSize: 13,
                    fontWeight: 700,
                    cursor: "pointer",
                  }}
                >
                  Satın Al
                </div>
                <div
                  className="tap"
                  onClick={() =>
                    showToast("Ətraflı məlumat yüklənir...")
                  }
                  style={{
                    background: t.card2,
                    borderRadius: 10,
                    padding: "12px 14px",
                    color: t.accent,
                    fontSize: 13,
                    fontWeight: 600,
                    cursor: "pointer",
                    border: `1px solid ${t.border}`,
                  }}
                >
                  Ətraflı
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );

  const screens = {
    home: <HomeScreen />,
    vehicle: <VehicleScreen />,
    service: <ServiceScreen />,
    emergency: <EmergencyScreen />,
    shop: <ShopScreen />,
    insurance: <InsuranceScreen />,
  };

  return (
    <Phone>
      {/* Content */}
      <div
        style={{
          flex: 1,
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {screens[tab]}
      </div>

      {/* Bottom Tab Bar */}
      <div
        style={{
          position: "fixed",
          bottom: 0,
          left: "50%",
          transform: "translateX(-50%)",
          width: "100%",
          maxWidth: 420,
          background: dark
            ? "rgba(10,14,39,0.95)"
            : "rgba(248,250,252,0.95)",
          borderTop: `1px solid ${t.border}`,
          backdropFilter: "blur(30px)",
          padding: "8px 4px 20px",
          display: "flex",
          zIndex: 50,
        }}
      >
        {TABS.map((tb) => {
          const active = tab === tb.id;
          return (
            <div
              key={tb.id}
              className="tab-btn"
              onClick={() => setTab(tb.id)}
              style={{
                flex: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: 6,
                cursor: "pointer",
                position: "relative",
              }}
            >
              <div
                style={{
                  width: 44,
                  height: 44,
                  borderRadius: 12,
                  background: active ? t.accentSoft : "transparent",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 20,
                  color: active ? t.accent : t.sub,
                  transition: "all 0.3s",
                  border: `1px solid ${active ? t.accent + "40" : "transparent"}`,
                }}
              >
                {tb.icon}
              </div>
              <div
                style={{
                  fontSize: 9,
                  fontWeight: active ? 700 : 500,
                  color: active ? t.accent : t.sub,
                  letterSpacing: 0.2,
                  lineHeight: 1,
                }}
              >
                {tb.label}
              </div>
            </div>
          );
        })}
      </div>

      {/* Toast */}
      {toast && (
        <div
          style={{
            position: "fixed",
            bottom: 100,
            left: "50%",
            transform: "translateX(-50%)",
            background: dark
              ? "rgba(19,24,41,0.95)"
              : "rgba(255,255,255,0.95)",
            border: `1px solid ${t.green}40`,
            borderRadius: 12,
            padding: "12px 20px",
            fontSize: 13,
            fontWeight: 600,
            color: t.green,
            whiteSpace: "nowrap",
            backdropFilter: "blur(20px)",
            boxShadow: "0 8px 32px rgba(0,0,0,0.2)",
            zIndex: 200,
            animation: "fadeUp 0.3s ease",
          }}
        >
          ✓ {toast.msg}
        </div>
      )}
    </Phone>
  );
}
